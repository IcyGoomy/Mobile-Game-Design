﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SFX_Script : MonoBehaviour
{
     public AudioClip Pop_1;

     public AudioSource source;

     private static SFX_Script instance;

     private void Awake()
     {
	if(instance != null)
	{
		Destroy(gameObject);
	}

	else
	{
		instance = this;
		DontDestroyOnLoad(transform.gameObject);
	}
     }
}
