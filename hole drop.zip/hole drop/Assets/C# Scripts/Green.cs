﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Green : MonoBehaviour
{
	private SFX_Script sfxScript;
	private AudioClip pop;
	private AudioSource source;
	public string tagToDestroy;

	private void Start()
	{
		sfxScript = GameObject.FindWithTag("SFX").GetComponent<SFX_Script>();
		source = sfxScript.gameObject.GetComponent<AudioSource>();
		
		pop = sfxScript.Pop_1;
		
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag(tagToDestroy))
		{
			sfxScript.source.PlayOneShot(pop);
			//SceneManager.LoadScene(3);
		}
	}
}