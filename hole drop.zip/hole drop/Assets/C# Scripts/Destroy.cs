﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
	public string tagToDestroy;

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag(tagToDestroy))
		{
			Destroy(other.gameObject);
		}
	}
}
