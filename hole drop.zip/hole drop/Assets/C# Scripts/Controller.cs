﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    public float speed;
    private float screenWidth;

    private void Start()
    {
	screenWidth = Screen.width / 2;
    }

    void Update()
    {
        
	KeyboardControl();
	TouchControl();
	
     }

     void KeyboardControl()
     {

	if (Input.GetKey(KeyCode.A))
	{
	     transform.Rotate(0, 0, speed * Time.deltaTime);
	}
	else if (Input.GetKey(KeyCode.D))
	{
	     transform.Rotate(0, 0, -speed * Time.deltaTime);
	}

    }
    void TouchControl()
    {
	if (Input.touchCount > 0)
	{
	 Touch touch = Input.GetTouch(0);
	  if(touch.position.x < screenWidth)
		{
			transform.Rotate(0, 0, speed * Time.deltaTime);
		}
	  else if (touch.position.x > screenWidth)
		{
			transform.Rotate(0, 0, -speed * Time.deltaTime);
		}
	}
     }
}
