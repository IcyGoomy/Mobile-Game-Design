﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Touch_Controls : MonoBehaviour
{
    private float screenWidth;

    private void Start()
    {
	screenWidth = Screen.width / 2;
    }

    void Update()
    {
        
	KeyboardControl();
	TouchControl();
	
     }

     void KeyboardControl()
     {

	if (Input.GetKey(KeyCode.A))
	{
	    SceneManager.LoadScene(1);
	}
	else if (Input.GetKey(KeyCode.D))
	{
	    SceneManager.LoadScene(2);
	}

    }
    void TouchControl()
    {
	if (Input.touchCount > 0)
	{
	 Touch touch = Input.GetTouch(0);
	  if(touch.position.x < screenWidth)
		{
			SceneManager.LoadScene(1);
		}
	  else if (touch.position.x > screenWidth)
		{
			SceneManager.LoadScene(2);
		}
	}
     }
}
